For running this project you need to do the following steps:

0. Unzip the zip file
1. npm install
2. npm run start

Hope you will like it!
P