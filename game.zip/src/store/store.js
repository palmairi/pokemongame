export const cardImages = [
    'card-poke1.png',
    'card-poke2.png',
    'card-poke3.png',
    'card-poke4.png',
    'card-poke5.png',
    'card-poke6.png',
    'card-poke7.png',
    'card-poke8.png',
    'card-poke9.png',
    'card-poke10.png',
];
